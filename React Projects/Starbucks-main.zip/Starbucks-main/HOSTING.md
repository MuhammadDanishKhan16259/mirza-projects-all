# Starbucks
Starbucks clone with React JS

Hosting Link
************
https://starbucks-clone-6d500.web.app/
************
