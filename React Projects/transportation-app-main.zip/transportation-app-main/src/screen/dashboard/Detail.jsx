export default function Detail() {
  return (
    <section className="Detail">
      <div className="heading">
        <h1>Detail</h1>
      </div>
    </section>
  );
}
