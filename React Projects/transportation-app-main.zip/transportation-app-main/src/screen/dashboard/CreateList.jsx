export default function CreateList() {
  return (
    <section className="CreateList">
      <div className="heading">
        <h1>Create List</h1>
      </div>
    </section>
  );
}
