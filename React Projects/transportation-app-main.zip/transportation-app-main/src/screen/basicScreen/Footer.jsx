// import { Link, useNavigate } from "react-router-dom";

// style
import "../../style/basic/Footer.scss";

export default function Footer() {
  // let navigate = useNavigate();
  return (
    <section className="footer">
      {/* <div className="parentFooter">
        <div className="box11">
          <div className="logo">
            <h1 onClick={() => navigate("/")}>TPA</h1>
            <p>The Professional Academy</p>
          </div>
          <p>0314-2255-345</p>
        </div>
        <div className="box12">
          <h1>Pages</h1>
          <ul>
            <li>
              <Link to={"course"}>Course</Link>
            </li>
            <li>
              <Link to={"quiz"}>Quiz</Link>
            </li>
            <li>
              <Link to={"result"}>Result</Link>
            </li>
            <li>
              <Link to={"login"}>Login</Link>
            </li>
            <li>
              <Link to={"sign-up"}>Sign up</Link>
            </li>
          </ul>
        </div>
        <div className="box13">
          <h1>Registration Form</h1>
          <ul>
            <li>
              <Link to={"student-registration-form"}>
                Student Registration Form
              </Link>
            </li>
            <li>
              <Link to={"trainer-registration-form"}>
                Trainer Registration Form
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="childFooter">
        <h4>
          Copyright © 2022 TPA (The Professional Academy) All rights reserved
        </h4>

        <div className="goToTop">
          <a href="#">
            <i className="fa-solid fa-angle-up"></i>
          </a>
        </div>
      </div> */}
    </section>
  );
}
