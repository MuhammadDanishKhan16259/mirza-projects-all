import React from "react";
import {Link} from "react-router-dom";

const Navbar1 = () => {
  return (
    <>
      <Link to="/">One</Link>
      <Link to="three">Three</Link>
      <Link to="four">Four</Link>
    </>
  );
};

export default Navbar1;
