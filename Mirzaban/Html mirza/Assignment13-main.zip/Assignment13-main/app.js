let long = document.querySelector(".long");
let long1 = document.querySelector(".long1");
long.addEventListener("click",f1)
function f1(){
    long1.classList.toggle("active");
    console.log("welcome")
}

let asd1 = document.querySelector(".asd1");
let asd2 = document.querySelector(".asd2");
asd1.addEventListener("click",f2)
function f2(){
    asd2.classList.toggle("active");
    console.log("welcome")
}
console.log("welcoem")




