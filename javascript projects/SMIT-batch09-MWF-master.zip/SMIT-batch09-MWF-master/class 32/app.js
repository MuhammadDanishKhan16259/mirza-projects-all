// alert("HELLO CLASS..")

// var age = 20

// if (age !== 20) {
//     console.log("TRUE")
// } else {
//     console.log("false")

// }


//       ARRAY

// var fruit1 = "mango"
// var fruit2 = "apple"
// var fruit3 = "orange"

// console.log(fruit1)

// 0        1        2   indexes
// var fruits = ["mango", "apple", "orange"]
// console.log(fruits[0])
// console.log(fruits[1])
// console.log(fruits[2])
// console.log(fruits[4])


// var numArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
// console.log(numArr)



// var mixArr = ["apple", 10]
// console.log(mixArr)

// var showValue = "number"

// if (showValue === "string") {
//     console.log(mixArr[0])
// } else {
//     console.log(mixArr[1])

// }


// var name;
// name = "Jaffar aman"
// console.log(name)

// var arr = [];   //empty array
// arr[0] = "jaffar"
// arr[1] = "aman"
// arr[2] = "sufiyan"
// arr[3] = "bilal"
// arr[5] = "bilal"
// arr[4] = null




// console.log(arr)

// var stdArr = ["Ali", 20, true, undefined, null]
// console.log(stdArr[4])


// var stdArr = ["Jaffar", "Sufiyan"]

// pop and push  =>>>   last index   (pop => remove | push => add)
// stdArr.push("Bilal")
// stdArr.pop()



// console.log(stdArr)




// ///Shift OR UNShift
// var stdArr = ["Jaffar", "Sufiyan"]
// // stdArr.unshift("bilal", "Ali")
// // stdArr.shift(3)
// console.log(stdArr)



// pop push
// shift and unshift


//slice
var stdArr = ["jaffar", "sufiyan", "ali", "talha", "yousuf"]

var stdArrCopy = stdArr.slice(-1)


console.log(stdArrCopy)







