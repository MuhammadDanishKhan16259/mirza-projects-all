// var value = '500' - 200
// console.log(value)


// BODMAS RULE
// var value = "jaffar" + (50 + 30)
// console.log(value)


// var firstName = "Jaffar";
// console.log(value)


// var a = 10

// // var add = 10  //POST increment    pehly print bad main add
// var add = ++a   //PRE increment  pehly add phr print

// console.log("add=>>>>", add)
// console.log("a=>>>>", a)



// var value = a++ + ++a
//   = 10 + 12

// var value = a++ + a++ + ++a + a + a++;
//   = 10  + 11  + 13  + 13 + 13


// POST pehly print phr add
// PRE   pehly add phr print

// var a = 15;   //16 //17 //18  19 20  21

// var value = ++a + a++ + a++ + a + ++a
//   = 16 + 16 + 17 + 18 + 19

// var value = a + ++a + a++ + ++a + ++a + a++ + a++;
//         //   =  15 + 16 + 16  + 18 +  19   + 19 +  20

// console.log(value)

// var a = 10
// var value = --a
// console.log(value)

// var a = 10   // 10 +1 = 11 +1 == 12 - 1 = 11 - 1 = 10 - 9 + 1 =10
// var value = a++ + a++ - a-- + --a + a-- + a + ++a
// //   = 10  +  11 - 12  + 10  + 10  + 9 +  10
// console.log(value)






// var userName = "Jaffar Aman"

// var userName = prompt("Enter USER NAME")
// console.log("userName==>", userName)

// var value1 = +prompt("Enter value 1", 10)
// var value2 = +prompt("Enter value 2")

// console.log(typeof value1)

// var add = value1 + value2

// console.log(add)