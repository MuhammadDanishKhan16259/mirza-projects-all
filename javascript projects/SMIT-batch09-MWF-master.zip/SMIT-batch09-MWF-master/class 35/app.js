// console.log("HELLO CLASS..")


// for (var i = 1; i < 10; i++) {
//     console.log(i)
// }

// var stdArr = ["Ali", "john", "bilal", "sufiyan", "Jaffar", "Aman", "talha"]
// console.log(stdArr.length)
// console.log(stdArr[0])

// document.write("<h1>" + stdArr[0] + "</h1>")


// for (var i = 0; i < stdArr.length; i++) {
//     console.log(i, "index number")
//     document.write("<h1>" + stdArr[i] + "</h1>")
// }




// var cities = ["lahore", "multan", "islamabad"]

// if (cities[0] === "karachi") {
//     alert("the city of light")
// } else if (cities[1] === "karachi") {
//     alert("the city of light")

// } else if (cities[2] === "karachi") {
//     alert("the city of light")

// } else if (cities[3] === "karachi") {
//     alert("the city of light")

// } else {
//     alert("karachi is not exist")
// }

// var cities = ["lahore", "multan", "karachi", "islamabad"]

// for (var i = 0; i < cities.length; i++) {
//     console.log(cities[i])

//     if (cities[i] === "karachi") {
//         alert("the city of light")
//     }

// }

// var userCity = prompt("Enter your city")
// var cities = ["karachi" , "lahore", "multan", "islamabad"]
// var isMatch = false


// for (var i = 0;   i <  cities.length; i++) {

//     if (cities[i] === "delhi") {
//         console.log("true")
//         isMatch = true
//         alert("your city is exist")
//         break
//     }

// }


// if (isMatch === false) {
//     alert("your city is not exist")
// }


// for (var i = 0; i < 10; i++) {
//     if (i === 5) {
//         continue
//     }
//     console.log(i)
// }


//NESTED LOOP
for (var i = 0; i < 2; i++) {
    console.log(i, "outer loop")

    for (var j = 0; j < 5; j++) {
        console.log(j, "inner loop")
    }


}




var arr = new Array()
console.log(arr)