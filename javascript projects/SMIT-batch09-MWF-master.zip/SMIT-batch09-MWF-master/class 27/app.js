// alert("HELLO WORLD");



// Variables

// var myname = "Hello world";
// var myname = "hello class";  // variable


// alert(myname);



// var std1 = "Jaffar Aman";
// var std2 = "Sufiyan";
// var std3 = "Bilal";






// // String Variable
// var userName  = "Talha"  ///String Type
// // var userEmail = ""

// // Number Variable//  20 21 50 100 1 0 1000

// var userAge = 20


// alert(  userAge  )






// var  variableName = variableValue;


// var myName = "Jaffar";
// // alert(myName)


// var userName  = myName;


// DATA TYPES   ==> data =  values

// String   /// group OR Set of char   "  "  OR '   ' eg, "jaffar" , "jaff@"
// Number  //Number eg: 20 10 500
// Boolean //true false
// undefined
// null


// var stringVar = "jaffar10@gmail.com"

// var numberVar = 20;   //Number Data type
// // alert(stringVar)

// var isActive = true  

// alert(isActive)





// var gender = prompt('Tell your gender')
// var age = +prompt('Tell your age')

// function isUserAllowed(age, gender) {
//     if (age >= 18 && gender == 'male') {
//         alert('User is allowed')
//     } else {
//         alert('User is not allowed')
//     }
// }

// isUserAllowed(age, gender)


var mathsNumber = prompt('Maths marks')
var urduNumber = prompt('Urdu marks')
var englishNumber = prompt('English marks')

document.getElementById('maths').innerHTML =  mathsNumber
document.getElementById('english').innerHTML =  urduNumber
document.getElementById('urdu').innerHTML =  englishNumber










