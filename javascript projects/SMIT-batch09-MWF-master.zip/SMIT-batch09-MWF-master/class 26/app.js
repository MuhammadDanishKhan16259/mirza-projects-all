// alert("hello world")
// alert("HELLO CLASS 2")
// alert("HELLO CLASS")