// var arr = [[1, 2, 3, 4], ["a", "b", "c"]]  //multidimensional array

// console.log(arr[0][2], "arr")
// console.log("print c==>", arr[1][2])


// for (var i = 1; i <= 10; i++) {
//     console.log(i)
// }


// var fruits = ['apple', 'banana', 'mango', 'orange', 'strawberry']
// for (var i = 0; i < fruits.length; i++) {
//     document.write("Element at index " + i + " " + fruits[i], "<br >")
// }


// for (var i = 10; i >= 1; i--) {
//     document.write(i + "<br />")
// }

// even number
// for (var i = 0; i <= 100; i++) {
//     if (i % 2 == 0) {
//         console.log("even number", i)
//     }
// }

// odd number
// for (var i = 0; i <= 100; i++) {
//     if (i % 2 !== 0) {
//         console.log("odd number", i)
//     }
// }


var bakeryItem = ['cake', 'apple pie', 'cookie', 'chips', 'patties'];


// var userInput = prompt("Welcome to ABC bakery.What do you want to order")
// console.log(userInput, "userInput")

// var isMatch = false

// for (var i = 0; i < bakeryItem.length; i++) {
//     if (bakeryItem[i] === userInput) {
//         isMatch = true
//         document.write(userInput + " " + "is avaiable at index " + i + " in our bakery <br />")
//         break;
//     }
// }

// if (isMatch === false) {
//     document.write("We are sorry")
// }



// LARGEST number
// var num = [24, 53, 780, 91, 12, 100]
// var temp = 0


// for (var i = 0; i < num.length; i++) {
//     if (temp < num[i]) {
//         temp = num[i]
//     }
// }

// console.log("largest value of num array is ", temp)

// SMALLEST NUMBER
// var num = [24, 53, 780, 91, 12, 100, 5]
// var temp = num[0]

// for (var i = 0; i < num.length; i++) {
//     if (temp > num[i]) {
//         temp = num[i]
//     }
// }

// console.log("smallest value of num array is ", temp)


// var bakeryItem = ['cake', 'apple pie', 'cookie', 'chips', 'patties'];

// FIFO

// for (var i = 0; i < bakeryItem.length; i++) {
//     console.log(bakeryItem[i])
// }


// LIFO

// for (var i = bakeryItem.length - 1; i >= 0; i--) {
//     console.log(bakeryItem[i])
// }
