// alert("HELLO WORLD");
// alert("HELLO CLASS");



//DATA TYPES
// String    "  "  OR '  '
// Number   123456
// Boolean    TRUE / FALSE
// undefined
// null



// var fullName = "Jaffar Aman";   //STRING
// var age = 21;  // NUMBER
// var contactNumber = "03462528569";  //STRING
// var email = "amanjaffar50@gmail.com"; //STRING
// var isActive = true; //BOOL
// var result = undefined; //UNDEFINED
// var relationStatus = null; //NULL

// alert(fullName)
// alert(age)
// alert(contactNumber)

// console.log(fullName)
// console.log(age)
// console.log(result)



// var firstName = "Jaffar";
// var lastName = "Aman";

// var fullName = firstName + " " + lastName
// console.log(fullName)


// var a = "10";  // number
// var b = 20;  // string

// var sum = a + b;

// console.log(sum)


// var value = "50" + 100  //concat   + sign
// console.log(value)


// + , - , * , / , %
// var a = "10";
// var b = 20;

// //ADD
// var add = a + b
// // console.log(add)


// //SUB
// var sub = a - b

// //MUL

// var mul = a * b
// // console.log(mul)

// //DIV
// var div = a / b
// // console.log(div)



// var reminder = 9 % 2  // 0
// console.log(reminder)



// var value = 10 + 20 - 64;
// var value = 10 + (10 - 30) - 20 + 10
//           = 10 + (-20) -20 +10
//            = 10 - 20 -20 +10
//            = 20 - 20 - 20
//             0 -20
//             -20

// console.log(value)

// var value2 = (10 - 20 * 2) + 20 - 10 * 5
//   =  (-30) - 30
//   = -30 - 30
//    = -60
// console.log(value2)

// var value = "Hello" + 10 + 20;

// var value2 = 20 + "HELLO" + 10
// var value3 = "10" + 20 + "HELLO"
// var value4 = "HELLO" + (10 + 20)

// console.log(value4)


camelCase

var first_Name = "jaffar"













