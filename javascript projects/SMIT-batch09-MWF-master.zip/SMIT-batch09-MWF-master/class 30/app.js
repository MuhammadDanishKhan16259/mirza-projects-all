// console.log("HELLO CLASS");

// var a = 10

// console.log(++a);
// console.log(a)



// true condition
// if (condition) {
//     // Block of statements
//     console.log("ALLOW")
// }
// // false condition
// else {
//     console.log("NOT ALLOW")
// }

// if else
// if =>>> true condition
// else =>>> false condition


// if(condition){

// }else{

// }


// var userAge = 18;
// if (userAge == 20) {
//     console.log("ALLOW")
// } else {
//     console.log("NOt ALlow")
// }

// console.log(userAge)




// var gender = prompt("Enter your gender")

// if (gender == "male") {
//     console.log("ALLOW")
// } else {
//     console.log("NOT ALLOW")
// }




// = =>>assigning opt
// ==   =>>> check value
// ===  =>>  check value & data type

// var value = "20"
// console.log(typeof value)
// if (value === "20") {
//     console.log("OK")
// } else {
//     console.log("false")
// }




// var userAge = +prompt("Enter your age")

// string === number  // false



// greater then
// if (userAge > 18) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }

// less then
// if (userAge < 18) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }


// greater and equal

// if (userAge >= 18) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }


// less then and equal
// if (userAge <= 18) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }




// var userAge = +prompt("Enter your age");
// var userGender = prompt("Enter your gender");


// if (userAge == 20 && userGender == "female") {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }

// age = 20
// gender = male
// if (userAge >= 18 && userAge <= 40 && (userGender == "male" || userGender == "female")) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }

// if ( true &&  true && true) {
//     console.log("USER ALLOW")
// } else {
//     console.log("USER NOT ALLOW")
// }












