console.log("HELLO CLASS...");

// var userAge = prompt("Enter your age...")

// if (userAge === 20) {
//     console.log("ALLOW")
// } else {
//     console.log("NOT ALLOW")
// }


//     false         ||  true
// if (userAge >= 20 || userAge <= 50) {
//     console.log("ALLOW")

// } else {
//     console.log("NOT ALLOW")

// }


// var edu = "intermediate"

// if (edu === "matric") {
//     console.log("ALLOW MODULE A")
// } else if (edu === "intermediate") {
//     console.log("ALLOW MODULE B")
// } else {
//     console.log("NOT ALLOW")
// }

// var userAge = +prompt("Enter your age");

// if (userAge >= 0 && userAge < 18) {
//     console.log("YOU ARE KID")
// } else if (userAge >= 18 && userAge <= 30) {
//     console.log("YOU ARE LEGEND....")
// } else if (userAge > 30 && userAge <= 50) {
//     console.log("YOUR ARE ULTRA LEGEND....")

// } else if (userAge > 50 && userAge <= 80) {
//     console.log("YOUR ARE PRO  LEGEND....")
// } else if (userAge > 80 && userAge <= 100) {
//     console.log("STAY HOME")
// } else {
//     console.log("DEAD")
// }



// NESTED IF

// var userAge = 20;
// var userGender = "female";

// if (userAge >= 20) {
//     if (userGender === "male") {
//         console.log("ALLOW")
//     } else {
//         console.log("your gender is not match..")
//     }
// } else {
//     console.log("YOUR ARE IS LESS")
// }


// if (userAge >= 20 && userGender === "male") {
//     console.log("ALLOW")
// } else {
//     console.log("NOT ALLOW")
// }



// MARK SHEET   using if else , variable, opt,
// CALCULATOR


// var number1 = +prompt("ENTER NUMBER 1")
// var number2 = +prompt("ENTER NUMBER 2")
// var opt = prompt("ENTER opt")


// if (opt === "+") {
//     console.log(number1 + number2)
// } else if (opt === "-") {
//     console.log(number1 - number2)
// } else if (opt === "*") {
//     console.log(number1 * number2)

// } else if (opt === "/") {
//     console.log(number1 / number2)

// } else {
//     console.log("INVALID OpT")
// }



// var num1 = 500
// sum of 500 + 500 =  1000
// console.log("sum of " + num1 + " + " + num1 + " = " + (num1 + num1))



// 80 && 100 == A +
// 70 && 79 == A
// 60 && 69 == B
// 50 && 59 == C
// 40 && 49 == D
// 0 && 39 == Fail


// var percentage = +prompt("Enter your percentage...");

// if (percentage >= 80 && percentage <= 100) {
//     console.log("A+")
// } else if (percentage >= 70 && percentage <= 79) {
//     console.log("A")

// }



///CHAPTER # 01
// Question # 1
// alert("WELCOME")
// Question # 02
confirm("enter ")



var username = "jaffar";
document.write(username)
