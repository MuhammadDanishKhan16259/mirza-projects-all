// console.log("HELLO CLASS..")

// [] => Array  bracket
// length =>      1        2      3
// var fruits = ["mango", "orange", "apple"]
// indexNum =>   0         1        2
// console.log("old array", fruits)

//pop , Push  , shift and unShift , slice , splice

// fruits.pop()  // => last value remove
// fruits.push("graphs")  // => add  value remove

// fruits.shift()
// fruits.unshift("graph")
// console.log("new array", fruits)


//SLICE =>> ARRAY COPY
// var fruits = ["mango", "orange", "apple", 1, 100, 500]
// console.log("fruits", fruits)
// var arrCopy = fruits.slice(0,2)
// var arrCopy = fruits.slice(0)
// var arrCopy = fruits.slice(0,-2)
// var arrCopy = fruits.slice(-2)
// console.log("arrCopy", arrCopy)

// var fruits = ["mango", "orange", "apple", 1, 100, 500]
// // splice =>  remove and ADD
// console.log("before splice", fruits)

// fruits.splice(4, 1, 50, 999, 1599)
// console.log("after splice", fruits)

// var fruits = ["mango", "orange", "apple", 1, 100, 500]
// // fruits[6] = 600
// fruits = []
// console.log(fruits)


// console.log(" jaffar  'aman'  ")

// document.write("<table border='1'> <tr> <th>NAME</th>  </tr> <tr><td>JAFFAR AMAN</td></tr>     </table>")

// document.write("HELLO WORLD! <br />")

// for loop
// 1 2  10
// for (var i = 0; i < 10; i++) {
//     console.log("HELLO WORLD")
// }



for (var i = 0; i <= 5; i++) {
    console.log(i, "loop")
}



