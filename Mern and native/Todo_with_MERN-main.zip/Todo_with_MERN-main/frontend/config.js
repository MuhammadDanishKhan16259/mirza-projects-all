const URL_NAME = 'http://192.168.2.102:8080/api/todo';
// const URL_NAME = "";

export default URL_NAME;
