import {View, Text} from 'react-native';

function CardScreen() {
  return (
    <View>
      <Text>Welcome</Text>
    </View>
  );
}

export default CardScreen;
