import {View, Text} from 'react-native';

function FavouriteScreen() {
  return (
    <View>
      <Text>Welcome</Text>
    </View>
  );
}

export default FavouriteScreen;
