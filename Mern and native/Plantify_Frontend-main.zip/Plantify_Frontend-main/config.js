// const DBURL = 'http://192.168.2.101:8080/api';
const DBURL = 'https://chocolate-chipmunk-yoke.cyclic.app/api';

export default DBURL;
