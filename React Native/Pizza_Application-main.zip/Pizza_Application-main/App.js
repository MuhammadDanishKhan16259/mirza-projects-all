// component
import MyApp from './myFolder/MyApp';

const App = () => {
  return (
    <>
      <MyApp />
    </>
  );
};

export default App;
