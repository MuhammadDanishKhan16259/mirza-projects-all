# **Doctor application**  
Doctor application: Through this application, a doctor can store their patient record and check their details.  
  

# **Features**  

- Beautiful loading on buttons  
- Fully Functional  
- Attractive design & colors  
- Beautiful loading adds in home screen when data is fetching  

# **🛠️ Using Technologies**  
<div align="left">  
<a href="https://www.javascript.com/" target="_blank"><img style="margin: 10px" src="https://profilinator.rishav.dev/skills-assets/javascript-original.svg" alt="JavaScript" height="50" /></a>  
<a href="https://firebase.google.com/" target="_blank"><img style="margin: 10px" src="https://profilinator.rishav.dev/skills-assets/firebase.png" alt="Firebase" height="50" /></a>  
</div>  

# **Screenshots**  
![Page: 01](https://github.com/shaykhmirzaban/Doctor_Application/blob/main/screenshot-1672039157413.png?raw=true)  
![Page: 02](https://github.com/shaykhmirzaban/Doctor_Application/blob/main/screenshot-1672039425101.png?raw=true)  
![Page: 03](https://github.com/shaykhmirzaban/Doctor_Application/blob/main/screenshot-1672039445908.png?raw=true)  
![Page: 04](https://github.com/shaykhmirzaban/Doctor_Application/blob/main/screenshot-1672039458988.png?raw=true)  
  

# **🔗Connect with me**  
<a href="https://github.com/https://github.com/shaykhmirzaban" target="_blank">
<img src=https://img.shields.io/badge/github-%2324292e.svg?&style=for-the-badge&logo=github&logoColor=white alt=github style="margin-bottom: 5px;" />
</a>
<a href="https://linkedin.com/in/https://www.linkedin.com/in/shaykh-mirzaban-7b51651a5/" target="_blank">
<img src=https://img.shields.io/badge/linkedin-%231E77B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white alt=linkedin style="margin-bottom: 5px;" />
</a>  
  

# **Feedback**  
If you have any feedback, please reach out to us at  
shaykhmirzaban@gmail.com  

<br />
