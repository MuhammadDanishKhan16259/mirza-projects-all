# Restaurant-Menu
React JS Practice

# Hosting Link
https://restaurant-menu-64eb6.web.app/