import React from "react";
import Todo from "./components/Todo";

function App() {
  return (
    <React.StrictMode>
      <Todo />
    </React.StrictMode>
  );
}

export default App;
