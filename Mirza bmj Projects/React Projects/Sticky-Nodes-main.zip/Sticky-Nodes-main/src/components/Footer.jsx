import React from "react";
import "../style/footer.css";

const Footer = () => {
  return (
    <>
      <section className="footer">
        <h5>Copyright © 2022 Shaykh Mirzaban All rights reserved</h5>
      </section>
    </>
  );
};

export default Footer;
