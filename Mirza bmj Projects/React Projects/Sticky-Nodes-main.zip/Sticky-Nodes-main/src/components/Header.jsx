import React from "react";
import "../style/Header.css";

const Header = () => {
    return (
        <>
            <section className="header">
                <h1>Mirzaban Notes</h1>
            </section>
        </>
    )
};

export default Header;