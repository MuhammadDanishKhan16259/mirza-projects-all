// css
import "../style/Footer.scss";

function Footer() {
  return (
    <section className="footer">
      <p>Copyright © 2022 Shaykh Mirzaban All rights reserved</p>
    </section>
  );
}

export default Footer;
