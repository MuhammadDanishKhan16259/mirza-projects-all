import MyApp from './Myfolder/MyApp';

function App() {
  return <MyApp />;
}

export default App;
