import StackNavigation from './navigation/StackNavigation';

function MyApp() {
  return <StackNavigation />;
}

export default MyApp;
