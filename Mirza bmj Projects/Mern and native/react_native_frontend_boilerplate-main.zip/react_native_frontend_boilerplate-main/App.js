// components
import MyApp from './myFolder/MyApp';

function App() {
  return (
    <>
      <MyApp />
    </>
  );
}

export default App;
