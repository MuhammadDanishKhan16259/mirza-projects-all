let DBURL = 'http://192.168.2.100:8080/api';
// let DBURL = "http://192.168.2.100:8080/api";

export default DBURL;
