// CHAPTER 3
// *********
// VARIABLES FOR NUMBERS
// *********************
// 1
// *
let age = "I am 18 years old";
alert(age);
// 2
// *
let n = 14; 
let visited = "You have visited this site"+ n +" times";
alert(visited);
// 3
// *
let birthYear = "2003";
alert("My birth year is " + birthYear);
// 4
// *
let visitorName = "John Doe";
let productTitle = "T-shirt(s)";
let quantity = 5;
document.write(visitorName + " ordered " + quantity + " " + productTitle + " on XYZ Clothing store");

//  END
//  ***