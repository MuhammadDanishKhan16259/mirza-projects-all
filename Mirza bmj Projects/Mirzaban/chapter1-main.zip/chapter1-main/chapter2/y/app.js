// CHAPTER 2
// *********
// VARIABLES FOR STRINGS
// *********************
// 1
// *
let userName;
// 2
// *
let myName = "Shaykh Miraban-ul-haq";
// 3
// *
let message = "Hello World";
alert(message);
// 4
// *
let studentName = "Jhone Doe";
let year = 15 + "years old";
let certified = "Certified Mobile Application Development";
alert(studentName);
alert(year);
alert(certified);
// 5
// *
let pizza = "PIZZA \n PIZZ \n PIZ \n PI \n P";
alert(pizza);
// 6
// *
let detail = "My email address is ";
let email = detail + "shaykhmirzaban@gmail.com";
alert(email);
// 7
// *
let book = "I am trying to learn from the book" + "A smarter way to learn JavaScript";
alert(book);
// 8
// *
document.write("Yah! I can write HTML content through JavaScript" + "<br>");
// 9
// *
let design = "▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
alert(design);
document.write(design);
// END
// ***