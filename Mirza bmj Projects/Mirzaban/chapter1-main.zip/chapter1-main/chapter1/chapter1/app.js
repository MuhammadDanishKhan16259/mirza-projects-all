// CHAPTER 1
// ********
// Topic name "Alert"
//            ******
// 1
// *
alert("Greet");
window.alert("Greet");
// 2
// *
let validPassword = "Please enter a valid password.";
let error1 = "Error!";
alert(error1 + " " + validPassword);
// simple way
// *********
alert("Error! Please enter a valid password.");
// 3
// *
let welcome = "Welcome to JS land...";
let happy = "Happy Coding!";
alert(welcome + "\n" + happy);
alert(welcome + "\r" + happy);
alert(welcome + "\n\r" + happy);
// 4
// *
alert("Welcome to JS land...");
window.alert("Happy Coding!");
// 5
// *
// press f12 on the webpage select the console and write there this.👀
alert("Hello...I can run JS through my web browser's console.");
// 6
// *
// check index.html page